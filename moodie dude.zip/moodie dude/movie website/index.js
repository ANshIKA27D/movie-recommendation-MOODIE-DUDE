const KEY = "3fd2be6f0c70a2a598f084ddfb75487c";
const API_URL = `https://api.themoviedb.org/3/discover/movie?sort_by=popularity.desc&api_key=${KEY}&page=1`;
const IMG_PATH = "https://image.tmdb.org/t/p/w1280";
const SEARCH_API = `https://api.themoviedb.org/3/search/movie?api_key=${KEY}&query=`;
const TRENDING_API = `https://api.themoviedb.org/3/trending/movie/day?api_key=${KEY}`;
const trendingMoviesContainer = document.getElementById('trending-movies');

const main = document.getElementById("main");
const form = document.getElementById("form");
const search = document.getElementById("search");
const modal = document.getElementById("movieModal");
const movieTitle = document.getElementById("movieTitle");
const movieOverview = document.getElementById("movieOverview");
const trailerFrame = document.getElementById("trailerFrame");
const castList = document.getElementById("castList");

const getClassByRate = (vote) => {
  if (vote >= 7.5) return "green";
  else if (vote >= 7) return "orange";
  else return "red";
};

// Single getMovieDetails function that handles both movies and TV shows
const getMovieDetails = async (contentId, isTV = false) => {
  const endpoint = isTV ? 'tv' : 'movie';
  const response = await fetch(
    `https://api.themoviedb.org/3/${endpoint}/${contentId}?api_key=${KEY}&append_to_response=videos,credits`
  );
  return await response.json();
};

// Single showMovieDetails function that handles both movies and TV shows
const showMovieDetails = async (content) => {
  const isTV = !content.title; // If there's no title, it's a TV show
  const contentDetails = await getMovieDetails(content.id, isTV);
  
  // Set content title and overview
  movieTitle.textContent = content.title || content.name;
  movieOverview.textContent = content.overview;
  
  // Set up trailer
  const trailer = contentDetails.videos.results.find(
    (video) => video.type === "Trailer"
  );
  if (trailer) {
    trailerFrame.src = `https://www.youtube.com/embed/${trailer.key}`;
  } else {
    trailerFrame.src = '';
  }
  
  // Set up cast
  castList.innerHTML = contentDetails.credits.cast
    .slice(0, 8)
    .map(
      (actor) => `
        <div class="cast-member">
          <img src="${
            actor.profile_path
              ? IMG_PATH + actor.profile_path
              : "https://via.placeholder.com/150"
          }" 
            alt="${actor.name}">
          <div class="actor-name">${actor.name}</div>
          <div class="character-name">${actor.character}</div>
        </div>
      `
    )
    .join("");
    
  // Show modal
  modal.style.display = "block";
};

// Close modal when clicking the close button
document.querySelector(".close").onclick = () => {
  modal.style.display = "none";
  trailerFrame.src = ''; // Clear the iframe src when closing
};

// Close modal when clicking outside
window.onclick = (event) => {
  if (event.target === modal) {
    modal.style.display = "none";
    trailerFrame.src = ''; // Clear the iframe src when closing
  }
};

const showMovies = (movies) => {
  main.innerHTML = "";
  movies.forEach((movie) => {
    const { title, poster_path, vote_average } = movie;
    const movieElement = document.createElement("div");
    movieElement.classList.add("movie");
    movieElement.innerHTML = `
      <img
        src="${IMG_PATH + poster_path}"
        alt="${title}"
      />
      <div class="movie-info">
        <h3>${title}</h3>
        <span class="${getClassByRate(vote_average)}">${vote_average}</span>
      </div>
    `;
    
    movieElement.addEventListener("click", () => showMovieDetails(movie));
    main.appendChild(movieElement);
  });
};

const getMovies = async (url) => {
  const res = await fetch(url);
  const data = await res.json();
  showMovies(data.results);
};

getMovies(API_URL);

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const searchTerm = search.value;
  if (searchTerm && searchTerm !== "") {
    getMovies(SEARCH_API + searchTerm);
    search.value = "";
  } else history.go(0);
});

// Add new function to update hero section
const updateHeroSection = async () => {
  try {
    const res = await fetch(TRENDING_API);
    const data = await res.json();
    const trendingMovie = data.results[0]; // Get the top trending movie

    const heroContent = document.querySelector('.hero-content');
    const heroSection = document.querySelector('.hero');
    
    // Update hero background
    heroSection.style.backgroundImage = `
      linear-gradient(to right, rgba(0, 0, 0, 0.9) 30%, rgba(0, 0, 0, 0.4)),
      url('https://image.tmdb.org/t/p/original${trendingMovie.backdrop_path}')
    `;

    // Get a brief overview by limiting to first 150 characters
    const briefOverview = trendingMovie.overview.length > 150 
      ? trendingMovie.overview.substring(0, 150) + '...'
      : trendingMovie.overview;

    // Update hero content with title, brief overview, and buttons
    // In updateHeroSection function, update the buttons:
    heroContent.innerHTML = `
      <h1>${trendingMovie.title}</h1>
      <p class="hero-overview">${briefOverview}</p>
      <div class="hero-buttons">
        <button class="btn-primary" onclick="playMovie(${trendingMovie.id}, false)">▶ Play</button>
        <button class="btn-secondary" onclick="showMovieDetails(${JSON.stringify(trendingMovie).replace(/"/g, '&quot;')})">ℹ More Info</button>
      </div>
    `;

    // Update age rating
    const ageRating = document.querySelector('.age-rating');
    ageRating.textContent = trendingMovie.adult ? 'A 18+' : 'PG-13';

    // Store the trending movie data for later use
    heroContent.dataset.movieId = trendingMovie.id;
  } catch (error) {
    console.error('Error updating hero section:', error);
  }
};

// Call updateHeroSection when the page loads
document.addEventListener('DOMContentLoaded', () => {
  updateHeroSection();
  getMovies(API_URL);
});

// Function to handle play button click
const playMovie = async (contentId, isTV = false) => {
  try {
    const endpoint = isTV ? 'tv' : 'movie';
    const details = await fetch(
      `https://api.themoviedb.org/3/${endpoint}/${contentId}?api_key=${KEY}&append_to_response=videos,credits`
    ).then(res => res.json());
    
    // Update modal content
    document.getElementById('movieTitle').textContent = details.title || details.name;
    document.getElementById('movieOverview').textContent = details.overview;
    
    // Set up trailer
    const trailer = details.videos.results.find(video => video.type === "Trailer");
    if (trailer) {
      document.getElementById('trailerFrame').src = `https://www.youtube.com/embed/${trailer.key}?autoplay=1`;
    }
    
    // Update cast
    const castList = document.getElementById('castList');
    castList.innerHTML = details.credits.cast
      .slice(0, 8)
      .map(actor => `
        <div class="cast-member">
          <img src="${actor.profile_path ? IMG_PATH + actor.profile_path : 'https://via.placeholder.com/150'}" 
               alt="${actor.name}">
          <div class="actor-name">${actor.name}</div>
          <div class="character-name">${actor.character}</div>
        </div>
      `).join('');
    
    // Show modal
    document.getElementById('movieModal').style.display = 'block';
  } catch (error) {
    console.error('Error playing content:', error);
  }
};

const showTrendingMovies = (movies) => {
  trendingMoviesContainer.innerHTML = "";
  movies.slice(1, 7).forEach((movie) => { // Skip first movie as it's in hero
    const { title, poster_path, vote_average } = movie;
    const movieElement = document.createElement("div");
    movieElement.classList.add("movie");
    movieElement.innerHTML = `
      <img
        src="${IMG_PATH + poster_path}"
        alt="${title}"
      />
      <div class="movie-info">
        <h3>${title}</h3>
        <span class="${getClassByRate(vote_average)}">${vote_average}</span>
      </div>
    `;
    
    movieElement.addEventListener("click", () => showMovieDetails(movie));
    trendingMoviesContainer.appendChild(movieElement);
  });
};

// Add new API endpoints for different categories
const HOLLYWOOD_API = `https://api.themoviedb.org/3/discover/movie?api_key=${KEY}&with_original_language=en&sort_by=popularity.desc`;
const BOLLYWOOD_API = `https://api.themoviedb.org/3/discover/movie?api_key=${KEY}&with_original_language=hi&sort_by=popularity.desc`;
const KDRAMA_API = `https://api.themoviedb.org/3/discover/tv?api_key=${KEY}&with_original_language=ko&sort_by=popularity.desc`;
const CHINESE_API = `https://api.themoviedb.org/3/discover/tv?api_key=${KEY}&with_original_language=zh&sort_by=popularity.desc`;
const ANIME_API = `https://api.themoviedb.org/3/discover/tv?api_key=${KEY}&with_genres=16&with_original_language=ja&sort_by=popularity.desc`;

// Add references to new containers
const hollywoodContainer = document.getElementById('hollywood-movies');
const bollywoodContainer = document.getElementById('bollywood-movies');
const kdramaContainer = document.getElementById('kdrama-movies');
const chineseContainer = document.getElementById('chinese-movies');
const animeContainer = document.getElementById('anime-movies');

// Function to show movies in a container
const showCategoryMovies = (movies, container) => {
  container.innerHTML = "";
  movies.slice(0, 10).forEach((movie) => {
    const { title, name, poster_path, vote_average } = movie;
    const movieTitle = title || name; // TV shows use 'name' instead of 'title'
    const movieElement = document.createElement("div");
    movieElement.classList.add("movie");
    movieElement.innerHTML = `
      <img
        src="${poster_path ? IMG_PATH + poster_path : 'https://via.placeholder.com/150'}"
        alt="${movieTitle}"
      />
      <div class="movie-info">
        <h3>${movieTitle}</h3>
        <span class="${getClassByRate(vote_average)}">${vote_average}</span>
      </div>
    `;
    
    movieElement.addEventListener("click", () => showMovieDetails(movie));
    container.appendChild(movieElement);
  });
};

// Function to fetch and display category movies
const getCategoryMovies = async (url, container) => {
  try {
    const res = await fetch(url);
    const data = await res.json();
    showCategoryMovies(data.results, container);
  } catch (error) {
    console.error('Error fetching category movies:', error);
  }
};

// Update the page load event listener to include all categories
document.addEventListener('DOMContentLoaded', async () => {
  updateHeroSection();
  
  // Fetch and display trending movies
  try {
    const res = await fetch(TRENDING_API);
    const data = await res.json();
    showTrendingMovies(data.results);
  } catch (error) {
    console.error('Error fetching trending movies:', error);
  }
  
  // Fetch and display all category movies
  getCategoryMovies(HOLLYWOOD_API, hollywoodContainer);
  getCategoryMovies(BOLLYWOOD_API, bollywoodContainer);
  getCategoryMovies(KDRAMA_API, kdramaContainer);
  getCategoryMovies(CHINESE_API, chineseContainer);
  getCategoryMovies(ANIME_API, animeContainer);
});

// Update search functionality to include all content types
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const searchTerm = search.value;
  if (searchTerm && searchTerm !== "") {
    try {
      // Search for movies
      const movieRes = await fetch(SEARCH_API + searchTerm);
      const movieData = await movieRes.json();
      
      // Search for TV shows
      const tvRes = await fetch(`https://api.themoviedb.org/3/search/tv?api_key=${KEY}&query=${searchTerm}`);
      const tvData = await tvRes.json();
      
      // Combine and sort results by popularity
      const allResults = [...movieData.results, ...tvData.results]
        .sort((a, b) => b.popularity - a.popularity);
      
      showMovies(allResults);
      search.value = "";
    } catch (error) {
      console.error('Error searching content:', error);
    }
  } else {
    history.go(0);
  }
});

// Add mood selector functionality
const moodSelector = document.getElementById('mood-selector-container');

// Define moods and their corresponding genres
const moods = {
  happy: { emoji: '😊', genres: [35, 10751], description: 'Feel-good comedies and family movies' },
  sad: { emoji: '😢', genres: [18, 10749], description: 'Drama and romance to match your mood' },
  excited: { emoji: '🤩', genres: [28, 12], description: 'Action-packed adventures' },
  relaxed: { emoji: '😌', genres: [99, 36], description: 'Documentaries and historical pieces' },
  romantic: { emoji: '🥰', genres: [10749], description: 'Love stories and romantic films' },
  adventurous: { emoji: '🤠', genres: [12, 14], description: 'Epic adventures and fantasy' },
  mysterious: { emoji: '🤔', genres: [9648, 53], description: 'Mysteries and thrillers' },
  funny: { emoji: '😂', genres: [35], description: 'Comedy hits to lift your spirits' }
};

// Create mood selector UI
const createMoodSelector = () => {
  moodSelector.innerHTML = `
    <div class="mood-section">
      <h2>😁How are y🤪u feeling today?🤓</h2>
      <div class="mood-buttons">
        ${Object.entries(moods)
          .map(([mood, info]) => `
            <button class="mood-btn" data-mood="${mood}">
              ${info.emoji} ${mood.charAt(0).toUpperCase() + mood.slice(1)}
            </button>
          `).join('')}
      </div>
      <div id="mood-recommendations"></div>
    </div>
  `;

  // Add click event listeners to mood buttons
  const moodButtons = document.querySelectorAll('.mood-btn');
  moodButtons.forEach(button => {
    button.addEventListener('click', () => {
      const selectedMood = button.dataset.mood;
      getMoodBasedMovies(selectedMood);
    });
  });
};

// Get movies based on selected mood
const getMoodBasedMovies = async (mood) => {
  const selectedMood = moods[mood];
  const genreIds = selectedMood.genres.join(',');
  
  try {
    const response = await fetch(
      `https://api.themoviedb.org/3/discover/movie?api_key=${KEY}&with_genres=${genreIds}&sort_by=popularity.desc`
    );
    const data = await response.json();
    
    const recommendationsContainer = document.getElementById('mood-recommendations');
    recommendationsContainer.innerHTML = `
      <div class="mood-description">
        <p class="mood-text">${selectedMood.description}</p>
      </div>
      <div class="recommendations-row">
        ${data.results.slice(0, 6).map(movie => `
          <div class="movie" onclick="showMovieDetails(${JSON.stringify(movie).replace(/"/g, '&quot;')})">
            <img src="${IMG_PATH + movie.poster_path}" alt="${movie.title}">
          </div>
        `).join('')}
      </div>
    `;
  } catch (error) {
    console.error('Error fetching mood-based movies:', error);
  }
};

// Call createMoodSelector when the page loads
document.addEventListener('DOMContentLoaded', () => {
  createMoodSelector();
});

// Update the CSS styles
const style = document.createElement('style');
style.textContent = `
  .mood-section {
    padding: 2rem 4%;
    text-align: center;
  }
  
  .mood-section h2 {
    color: #FFD700;
    text-shadow: 2px 2px 4px rgba(255, 215, 0, 0.3);
    font-family: 'Montserrat', sans-serif;
    font-size: 3rem;
    font-weight: 700;
    margin-bottom: 2rem;
    text-transform: uppercase;
    letter-spacing: 2px;
    animation: mainTitleAnimation 3s ease-in-out infinite;
    position: relative;
    display: inline-block;
    transition: all 0.5s ease;
  }
  
  header marquee {
    background: transparent;
    margin-bottom: 1rem;
  }

  header h1 {
    color: #FFA500;
    text-shadow: 2px 2px 4px rgba(255, 165, 0, 0.3);
    font-family: 'Montserrat', sans-serif;
    font-size: 3rem;
    font-weight: 700;
    display: inline-block;
    text-transform: uppercase;
    letter-spacing: 2px;
    transition: all 0.3s ease;
    animation: glowPulse 3s ease-in-out infinite;
  }
  
  header h1:hover {
    color: #FF8C00;
    text-shadow: 
      -2px -2px 0 #FFA500,
      2px -2px 0 #FFA500,
      -2px 2px 0 #FFA500,
      2px 2px 0 #FFA500,
      4px 4px 8px rgba(255, 165, 0, 0.6);
    transform: scale(1.1) rotate(5deg);
  }

  @keyframes glowPulse {
    0% {
      color: #FFA500;
      text-shadow: 0 0 5px rgba(255, 165, 0, 0.5);
      transform: scale(1);
    }
    50% {
      color: #FF8C00;
      text-shadow: 
        0 0 10px rgba(255, 140, 0, 0.8),
        0 0 20px rgba(255, 140, 0, 0.5),
        0 0 30px rgba(255, 140, 0, 0.3);
      transform: scale(1.1);
    }
    100% {
      color: #FFA500;
      text-shadow: 0 0 5px rgba(255, 165, 0, 0.5);
      transform: scale(1);
    }
  }
  .mood-buttons {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 1rem;
    flex-wrap: nowrap;
    margin: 2rem auto;
    max-width: 1200px;
    overflow-x: auto;
    padding: 1rem;
    scrollbar-width: none;
  }
  
  .mood-buttons::-webkit-scrollbar {
    display: none;
  }
  
  .mood-btn {
    padding: 0.8rem 1.5rem;
    border: none;
    border-radius: 25px;
    background-color: var(--accent-color);
    color: #1a1a1a;
    font-family: 'Poppins', sans-serif;
    font-size: 1.1rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    white-space: nowrap;
    flex-shrink: 0;
  }
  
  .mood-btn:hover {
    transform: scale(1.05);
    background-color: #FFB833;
    color: #000000;
  }
  
  #mood-recommendations {
    margin-top: 2rem;
    padding: 2rem;
    background: linear-gradient(to right, rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.6));
    border-radius: 15px;
    box-shadow: 0 4px 15px rgba(255, 165, 0, 0.2);
  }
  
  #mood-recommendations h3 {
    color: var(--accent-color);
    margin-bottom: 1rem;
    font-size: 2rem;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 2px;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
  }
  
  #mood-recommendations p {
    color: #FFD700;
    margin-bottom: 2rem;
    font-size: 1.2rem;
    font-style: italic;
    line-height: 1.6;
    max-width: 800px;
    margin-left: auto;
    margin-right: auto;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
  }
  
  .recommendations-container {
    display: flex;
    gap: 1.5rem;
    overflow-x: auto;
    padding: 1.5rem 0;
    scrollbar-width: none;
    position: relative;
  }
  
  .recommendations-container::-webkit-scrollbar {
    display: none;
  }
  
  .recommendations-row {
    display: flex;
    justify-content: center;
    gap: 2.5rem;
    padding: 2rem;
    position: relative;
    overflow-x: auto;
    margin: 0 auto;
    max-width: 1400px;
  }
  
  .mood-text {
    font-family: 'Playfair Display', serif;
    font-size: 2rem;
    font-weight: 400;
    font-style: italic;
    color: #FFD700;
    text-align: center;
    margin: 2rem auto;
    padding: 1rem;
    text-transform: capitalize;
    letter-spacing: 1px;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
  }

  .movie {
    flex: 0 0 auto;
    width: 200px;
    margin: 0;
    transition: transform 0.3s ease;
    position: relative;
  }

  .movie img {
    width: 100%;
    height: 300px;
    border-radius: 8px;
    object-fit: cover;
  }

  .movie:hover {
    transform: scale(1.05);
    z-index: 2;
  }

  #mood-recommendations {
    margin-top: 3rem;
    padding: 3rem 2rem;
    background: linear-gradient(to right, rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.6));
    border-radius: 15px;
    box-shadow: 0 4px 15px rgba(255, 165, 0, 0.2);
  }
  
  #mood-recommendations h3 {
    color: var(--accent-color);
    margin-bottom: 1rem;
    font-size: 2rem;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 2px;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
  }
  
  #mood-recommendations p {
    color: #ccc;
    margin-bottom: 2rem;
    font-size: 1.2rem;
    font-style: italic;
    line-height: 1.6;
    max-width: 800px;
    margin-left: auto;
    margin-right: auto;
  }
  
  .recommendations-container {
    display: flex;
    gap: 1.5rem;
    overflow-x: auto;
    padding: 1.5rem 0;
    scrollbar-width: none;
    position: relative;
  }
  
  .recommendations-container::-webkit-scrollbar {
    display: none;
  }
  
  .recommendations-row {
    display: flex;
    gap: 1rem;
  }
`;
document.head.appendChild(style);

// Add Google Fonts link to the document head
const fontLink = document.createElement('link');
fontLink.href = 'https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Playfair+Display:ital@0;1&family=Poppins:wght@400;600&display=swap';
fontLink.rel = 'stylesheet';
document.head.appendChild(fontLink);